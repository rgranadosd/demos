#!/usr/bin/env bash
# Compila el InputSanitizationSynapseHandler (Synapse Handler GLOBAL) como FRAGMENT
# BUNDLE de synapse-core (para que el SynapseHandlersLoader vea la clase) y lo
# registra en deployment.toml. Aplica a TODAS las APIs desde un solo sitio y
# persiste (config-mapper regenera synapse-handlers.xml desde el TOML al arrancar).
set -euo pipefail

APIM_HOME="${APIM_HOME:-/Users/rafaelgd/Develop/wso2/apim}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$SCRIPT_DIR/src/main/java/com/example/apim/guardrails/InputSanitizationSynapseHandler.java"
TARGET="$SCRIPT_DIR/target"; CLASSES="$TARGET/classes"
JAR="$TARGET/InputSanitizationSynapseHandler.jar"; MF="$TARGET/MANIFEST.MF"
TOML="$APIM_HOME/repository/conf/deployment.toml"
LOG4J="$APIM_HOME/repository/conf/log4j2.properties"
CLASS="com.example.apim.guardrails.InputSanitizationSynapseHandler"

[ -d "$APIM_HOME" ] || { echo "APIM_HOME no existe: $APIM_HOME" >&2; exit 1; }

SYN="$(find "$APIM_HOME/repository/components/plugins" -maxdepth 1 -name 'synapse-core_*.jar' | head -1)"
[ -n "$SYN" ] || { echo "No se encontró synapse-core en plugins" >&2; exit 1; }
SYNV="$(basename "$SYN" | sed -E 's/^synapse-core_(.*)\.jar$/\1/')"

# --- classpath: plugins + lib ---
CP=""
for d in "$APIM_HOME/repository/components/plugins" "$APIM_HOME/repository/components/lib"; do
  while IFS= read -r -d '' j; do CP="${CP:+$CP:}$j"; done < <(find "$d" -maxdepth 1 -name '*.jar' -print0)
done
rm -rf "$CLASSES"; mkdir -p "$CLASSES"
javac -encoding UTF-8 -source 11 -target 11 -cp "$CP" -d "$CLASSES" "$SRC"

# --- FRAGMENT bundle de synapse-core (clave: la clase debe ser visible a synapse-core) ---
cat > "$MF" <<EOF
Manifest-Version: 1.0
Bundle-ManifestVersion: 2
Bundle-Name: Input Sanitization Synapse Handler Fragment
Bundle-SymbolicName: com.example.apim.sanitize.fragment
Bundle-Version: 1.0.0
Fragment-Host: synapse-core;bundle-version="$SYNV"
Export-Package: com.example.apim.guardrails
EOF
jar cfm "$JAR" "$MF" -C "$CLASSES" .

# --- desplegar el fragment en dropins (OSGi) ---
rm -f "$APIM_HOME/repository/components/lib/InputSanitizationSynapseHandler.jar" \
      "$APIM_HOME/repository/components/lib/InputSanitizationHandler.jar" \
      "$APIM_HOME/repository/components/dropins/InputSanitizationMediator.jar" \
      "$APIM_HOME/repository/components/dropins/InputSanitizationSynapseHandler.jar" "$APIM_HOME/repository/components/dropins/InputSanitizationSynapseHandler_1.0.0.jar" "$APIM_HOME/repository/components/dropins/InputSanitizationHandler_1.0.0.jar"
cp "$JAR" "$APIM_HOME/repository/components/dropins/"

# --- revertir enfoques anteriores (templates per-API + secuencia global) ---
T="$APIM_HOME/repository/resources/api_templates"
for tpl in velocity_template.xml ai_api_template.xml; do
  [ -f "$T/$tpl.bak" ] && cp "$T/$tpl.bak" "$T/$tpl" && echo "revertido $tpl"
done
SEQ="$APIM_HOME/repository/deployment/server/synapse-configs/default/sequences"
rm -f "$SEQ/WSO2AM--Ext--In.xml" "$SEQ/InputSanitizationPolicy.xml"

# --- registrar el handler GLOBAL en deployment.toml (idempotente) ---
python3 - "$TOML" "$CLASS" <<'PY'
import sys
toml, cls = sys.argv[1], sys.argv[2]
s = open(toml, encoding="utf-8").read()
if "synapse_handlers.input_sanitization" in s:
    print("deployment.toml: synapse handler ya registrado (idempotente)")
else:
    block = ("\n[synapse_handlers.input_sanitization]\nenabled = true\n"
             f'class = "{cls}"\n')
    if not s.endswith("\n"): s += "\n"
    open(toml, "w", encoding="utf-8").write(s + block)
    print("deployment.toml: [synapse_handlers.input_sanitization] añadido")
PY

# --- logger INFO para ver el saneo (rootLogger está en ERROR) ---
python3 - "$LOG4J" <<'PY'
import sys, re
p = sys.argv[1]; s = open(p, encoding="utf-8").read()
if "logger.input-sanitize" in s:
    print("log4j2: logger ya presente (idempotente)")
else:
    m = re.search(r'(?m)^(loggers\s*=\s*)(.*)$', s)
    if m and "input-sanitize" not in m.group(2):
        s = s[:m.start()] + m.group(1) + m.group(2).rstrip() + ", input-sanitize" + s[m.end():]
    s += ("\nlogger.input-sanitize.name = com.example.apim.guardrails\n"
          "logger.input-sanitize.level = INFO\n")
    open(p, "w", encoding="utf-8").write(s)
    print("log4j2: logger com.example.apim.guardrails=INFO añadido")
PY

echo "OK: fragment bundle en dropins + registrado en deployment.toml (synapse-core $SYNV)"
