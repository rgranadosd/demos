# InputSanitizationPolicy (Synapse Handler GLOBAL vía deployment.toml)

Handler de Synapse GLOBAL (WSO2 APIM 4.x) que sanea el payload de entrada
(elimina Unicode invisible y neutraliza operadores peligrosos) en TODAS las APIs.

- `src/.../InputSanitizationSynapseHandler.java` — extiende `org.apache.synapse.AbstractSynapseHandler`.
- `build.sh` — compila (javac) → `components/lib`, registra el handler en
  `deployment.toml` ([synapse_handlers.input_sanitization]) y añade un logger INFO.

Persistente y global: el config-mapper regenera `synapse-handlers.xml` desde el TOML
en cada arranque → aplica a todas las APIs desde un solo sitio, sobrevive al reinicio,
sin tocar templates ni re-desplegar API por API. Tras cambiar el TOML hay que
REINICIAR APIM (el config-mapper corre al arrancar).

    APIM_HOME=/ruta/al/apim ./build.sh   # luego reiniciar APIM
