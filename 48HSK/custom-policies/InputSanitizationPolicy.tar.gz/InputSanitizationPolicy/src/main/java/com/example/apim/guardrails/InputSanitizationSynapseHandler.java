package com.example.apim.guardrails;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMAttribute;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNode;
import org.apache.axiom.om.OMText;
import org.apache.axis2.AxisFault;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.synapse.AbstractSynapseHandler;
import org.apache.synapse.MessageContext;
import org.apache.synapse.commons.json.JsonUtil;
import org.apache.synapse.core.axis2.Axis2MessageContext;
import org.apache.synapse.transport.passthru.util.RelayUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

import javax.xml.stream.XMLStreamException;
import java.io.IOException;
import java.util.Iterator;
import java.util.regex.Pattern;

/**
 * Synapse Handler GLOBAL (WSO2 APIM 4.x): se ejecuta en cada mensaje de TODAS las
 * APIs. Sanea el payload de entrada (elimina Unicode invisible y neutraliza
 * operadores peligrosos) en el flujo de request.
 *
 * Se registra en UN solo sitio, el deployment.toml:
 *   [synapse_handlers.input_sanitization]
 *   class = "com.example.apim.guardrails.InputSanitizationSynapseHandler"
 *
 * El config-mapper regenera synapse-handlers.xml desde el TOML en cada arranque
 * → persistente, global, sin tocar templates ni re-desplegar APIs.
 */
public class InputSanitizationSynapseHandler extends AbstractSynapseHandler {

    private static final Log log = LogFactory.getLog(InputSanitizationSynapseHandler.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final Pattern ESCAPED_INVISIBLE_UNICODE_PATTERN =
            Pattern.compile("(?i)\\\\u(?:200[b-f]|202[a-e]|206[0-4]|feff)");

    private static final Pattern INVISIBLE_PATTERN =
            Pattern.compile("[\\u200B\\u200C\\u200D\\u200E\\u200F\\u202A-\\u202E\\u2060-\\u2064\\uFEFF]");
    private static final Pattern DANGEROUS_PATTERN =
            Pattern.compile("&&|\\|\\||==|!=|>=|<=|<<|>>|;(?!\\s*$)|\\u0060[^\\u0060]*\\u0060|\\$\\([^)]*\\)");

    /** Flujo de request entrante (cliente → gateway): aquí saneamos el payload. */
    @Override
    public boolean handleRequestInFlow(MessageContext synCtx) {
        org.apache.axis2.context.MessageContext axis2Ctx =
                ((Axis2MessageContext) synCtx).getAxis2MessageContext();
        try {
            RelayUtils.buildMessage(axis2Ctx);
            boolean changed = JsonUtil.hasAJsonPayload(axis2Ctx)
                    ? sanitizeJson(axis2Ctx)
                    : sanitizeXmlOrText(axis2Ctx);
            if (changed && log.isInfoEnabled()) {
                log.info("InputSanitizationSynapseHandler sanitized request payload"
                        + formatRequestContext(axis2Ctx));
            }
        } catch (IOException | XMLStreamException e) {
            log.error("InputSanitizationSynapseHandler failed to sanitize the request payload", e);
        }
        return true;  // fail-open: nunca bloquea el flujo
    }

    @Override
    public boolean handleRequestOutFlow(MessageContext synCtx) {
        return true;
    }

    @Override
    public boolean handleResponseInFlow(MessageContext synCtx) {
        return true;
    }

    @Override
    public boolean handleResponseOutFlow(MessageContext synCtx) {
        return true;
    }

    private String formatRequestContext(org.apache.axis2.context.MessageContext axis2Ctx) {
        StringBuilder c = new StringBuilder();
        appendContextValue(c, "messageId", axis2Ctx.getMessageID());
        appendContextValue(c, "requestPath", axis2Ctx.getProperty("REST_SUB_REQUEST_PATH"));
        return c.toString();
    }

    private void appendContextValue(StringBuilder c, String key, Object value) {
        if (value == null) return;
        c.append(c.length() == 0 ? " - " : ", ").append(key).append('=').append(value);
    }

    private boolean sanitizeJson(org.apache.axis2.context.MessageContext axis2Ctx) throws AxisFault {
        String original = JsonUtil.jsonPayloadToString(axis2Ctx);
        try {
            JsonNode root = OBJECT_MAPPER.readTree(original);
            if (!sanitizeJsonNode(root)) return false;
            JsonUtil.getNewJsonPayload(axis2Ctx, OBJECT_MAPPER.writeValueAsString(root), true, true);
            JsonUtil.setContentType(axis2Ctx);
            return true;
        } catch (IOException e) {
            throw AxisFault.makeFault(e);
        }
    }

    private boolean sanitizeJsonNode(JsonNode node) {
        if (node == null) return false;
        boolean changed = false;
        if (node instanceof ObjectNode) {
            ObjectNode on = (ObjectNode) node;
            Iterator<String> names = on.fieldNames();
            while (names.hasNext()) {
                String f = names.next();
                JsonNode child = on.get(f);
                if (child instanceof TextNode) {
                    String o = child.asText(), s = sanitize(o);
                    if (!o.equals(s)) { on.put(f, s); changed = true; }
                } else {
                    changed = sanitizeJsonNode(child) || changed;
                }
            }
            return changed;
        }
        if (node instanceof ArrayNode) {
            ArrayNode an = (ArrayNode) node;
            for (int i = 0; i < an.size(); i++) {
                JsonNode child = an.get(i);
                if (child instanceof TextNode) {
                    String o = child.asText(), s = sanitize(o);
                    if (!o.equals(s)) { an.set(i, TextNode.valueOf(s)); changed = true; }
                } else {
                    changed = sanitizeJsonNode(child) || changed;
                }
            }
        }
        return changed;
    }

    private boolean sanitizeXmlOrText(org.apache.axis2.context.MessageContext axis2Ctx) {
        if (axis2Ctx.getEnvelope() == null || axis2Ctx.getEnvelope().getBody() == null) return false;
        return sanitizeNode(axis2Ctx.getEnvelope().getBody());
    }

    private boolean sanitizeNode(OMNode node) {
        boolean changed = false;
        if (node instanceof OMText) {
            OMText t = (OMText) node;
            String o = t.getText(), s = sanitize(o);
            if (!o.equals(s)) {
                OMText r = OMAbstractFactory.getOMFactory().createOMText(s);
                t.insertSiblingAfter(r); t.detach();
                return true;
            }
            return false;
        }
        if (node instanceof OMElement) {
            OMElement el = (OMElement) node;
            for (Iterator<?> it = el.getAllAttributes(); it.hasNext(); ) {
                OMAttribute a = (OMAttribute) it.next();
                String o = a.getAttributeValue(), s = sanitize(o);
                if (!o.equals(s)) { a.setAttributeValue(s); changed = true; }
            }
            for (Iterator<?> it = el.getChildren(); it.hasNext(); ) {
                changed = sanitizeNode((OMNode) it.next()) || changed;
            }
        }
        return changed;
    }

    private String sanitize(String input) {
        if (input == null || input.isEmpty()) return input;
        String a = ESCAPED_INVISIBLE_UNICODE_PATTERN.matcher(input).replaceAll("");
        String b = INVISIBLE_PATTERN.matcher(a).replaceAll("");
        return DANGEROUS_PATTERN.matcher(b).replaceAll(" ");
    }
}
